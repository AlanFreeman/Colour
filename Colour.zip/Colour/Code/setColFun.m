function m = setColFun(m) % functions, other than task functions, for setCol

	% Define function handles for functions in this file
	m.array = @array;
	m.radHorComb = @radHorComb;
	m.readFile = @readFile;

function loc = array(sep, wid) % calculate triangular array

%	Inputs:
%		sep = distance between nearest-neighbour nodes (deg)
%		wid = array width (deg)
% Output:
%		loc = node locations, [x, y] (deg): ls x 2, where ls is the number of nodes
% Method:
%		The code calculates a parallelogram of nodes and then crops it to a square.

	w = .5 * wid; % half-width (deg)
	u = exp(1i * pi / 3); % unit vector along oblique axis
	i = ceil((1 + real(u)) * w / sep); % number of nodes to right of centre
	x = linspace(- i, i, 2 * i + 1) * sep; % hor. dist. of nodes from centre (deg)
	i = ceil(w / (imag(u) * sep)); % number of nodes above centre
	y = linspace(- i, i, 2 * i + 1) * sep; % ver. dist. of nodes from centre (deg)
	loc = x' + y * u; % generate array of nodes
	loc = [real(loc(:)), imag(loc(:))]; % locations (deg): ls x 2, ls too big
	i = abs(loc); i = i(:, 1) <= w & i(:, 2) <= w; % nodes within square
	loc = loc(i, :); % locations of nodes within square (deg): ls x 2

function d = radHorComb(d, m) % combine horizontal cell field radii: Packer (02)

	% Split the data into eccentricity bins
	i = d.source == 'wide' & d.eccFun >= 16 & d.eccFun < 60; % relevant rows
	dC = d(i, :); % select wide fields and eccentricities with sufficient data
	bins = 8; % number of eccentricity bins
	[~, edge, bin] = histcounts(dC.eccFun, bins); % ecc. bin edges and indices

	%	Split each eccentricity bin into radius bins, calc. radius for each bin
	binRads = 4; % number of radius bins: each cone is contacted by 4 horizontal
		% cells, Wässle (89)
	r = zeros(bins, binRads); % radius: (eccentricity bin) x (radius bin)
	for i = 1: bins % loop over eccentricity bins
		dCC = dC(bin == i, :); % rows for this bin
		rC = dCC.radius; % radii in this bin (deg)
		[~, ~, binRad] = histcounts(rC, binRads); % bin number for radii
		for j = 1: binRads % loop over radius bins
			r(i, j) = mean(rC(binRad == j)); % mean of radii in current bin (deg)			
		end
	end
	
	% Calculate radii from the union of receptive fields
	switch m.radHor.method % choose method
		case 'grid' % count grid points
			%	*** This code is untested ***
			%	Create grid of points,
			% randomise horizontal cell locations, find which grid points lie
			% within union, divide number of union points by number of grid
			% points, multiply grid area by fraction

			% Loop over eccentricity bins
			for i = 1: bins
		
				% Create grid
				rMax = max(rC(i, :)); % maximum radius at this eccentricity (deg)
				x = rMax * (- 2: .1: 2); % grid x locations (deg)
				[x, y] = ndgrid(x); % grid points (deg)
				locG = [x(:), y(:)]; % grid location (deg): gs x 2
				locGs = size(locG, 1); % number of grid locations
				in = false(1, locGs); % grid point is in receptive field: 1 x gs
				rUnion = zeros(1, bins); % allocate storage
				for j = 1: binRads % loop over radius bins
		
					% Calculate receptive field locations
					mag = rC(i, j); % current field is one radius from cone (deg)
					ang = 2 * pi * rand; % and at a random angle (rad)
					locF = mag * exp(ang); % field location as vector (deg)
					for k = 1: locGs % loop over grid points
						in(k) = abs(locG - locF) <= mag;
					end
		
				end
		
				%	Calculate radius
				a = sum(in) / locGs; % union area (deg ^ 2)
				rUnion(i) = sqrt(a / pi); % radius (deg)
				disp(rUnion);
		
			end

		case 'sum' % sum squared radii

			r = sqrt(sum(r .^ 2, 2, 'omitnan')); % sum-of-squares radii (deg)

		case 'union' % find area of union of polygons

			% Loop over eccentricity bins
			pInit = nsidedpoly(100); % polygon: circular r.f. with radius 1 deg
			rPoly = nan(1, bins); % storage for calculate radii (deg)
			for i = 1: bins

				% Loop over radius bins
				p = polyshape; % storage for receptive fields
				for j = 1: binRads % scale and translate each receptive field
					mag = r(i, j); % current radius (deg)
					if ~ isnan(mag)
						pC = scale(pInit, mag); % correct field radius (deg)
						ang = - pi + .5 * pi * (j - 1); % angle spread around origin (rad)
						loc = mag * exp(1i * ang); % field location as complex vector (deg)
						pC = translate(pC, [real(loc), imag(loc)]);
							% translate so that circumference passes through origin
						p(j) = pC;
					end
				end

				% Calculate radius for this eccentricity bin
				p = union(p);
				%	figure('windowStyle', 'docked'); plot(p);
				rPoly(i) = sqrt(area(p) / pi); % calculate radius

			end
			r = rPoly'; % radius (deg): 1 x bins

	end

	% Store
	dC = repmat(dC(1, :), [bins, 1]); % one row for each bin
	eccCen = edge(1: bins) + .5 * (edge(2) - edge(1)); % centres of ecc. bins
	dC.eccFun = eccCen'; % ecc. bin centres (deg)
	dC.source(:) = 'field'; % method for calculating radius
	dC.radius = r; % radius (deg)
	d = [d; dC]; % concatenate

function d = readFile(folder) % read raw data in folder and return table

	% Read contents file
	d = readtable([folder, '/', 'Contents'], 'textType', 'string', ...
		'delimiter', 'tab', 'consecutiveDelimitersRule', 'join'); % contents table
	f = d.file; % names of files
	c = d.content; % names of input variables
	l = d.label; % labels of output data
	v = split(d.var(1), ', ', 2); % names of output variables
	desc = split(d.desc(1), ', ', 2); % descriptions of output variables
	
	% Complile a table from each mat-file
	fs = length(f); % number of files
	dC = cell(fs, 1); % allocate storage
	for i = 1: fs % loop over files
		fC = f(i); % current file
		if contains(fC, ".csv") % comma-separated variable file
			d = readtable([folder, filesep] + fC); % file contents as table
			cs = size(d, 1); lC = repmat(l(i), [cs, 1]); % contents label
			cC = [d.Var1, d.Var2]; % make it double
		else % mat-file
			fC = f(i) + ".mat"; % name of current file
			s = load([folder, filesep] + fC); % file contents: structure
			cC = c(i); % current content
			cC = s.(cC); % file contents: double
			cs = size(cC, 1); % number of rows
			lC = repmat(l(i), [cs, 1]); % contents label
		end
		dC{i} = table(lC, cC(:, 1), cC(:, 2), 'variableNames', ["label", v]);
	end

	% Combine and store
	d = vertcat(dC{:}); % combine data tables
	d.Properties.VariableDescriptions = ["label", desc]; % describe variables
